import Practice1 from "./components/Practice1";
import Chatting1 from "./components/Chatting1";
import Chatting2 from "./components/Chatting2";
import "./App.css";

function App() {
  return (
    <div>
      {/* 실습1 */}
      {/* <Practice1 /> */}
      {/* 실습2,3 */}
      {/* <Chatting1 /> */}
      {/* 실습3-1,2,3 */}
      <Chatting2 />
    </div>
  );
}

export default App;
